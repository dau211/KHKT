
import React from 'react';
import { ElementData } from '../types';

interface ElementCellProps {
  element: ElementData;
  onClick: () => void;
}

const categoryColors: { [key: string]: string } = {
  'diatomic nonmetal': 'bg-green-700 hover:bg-green-600',
  'noble gas': 'bg-purple-800 hover:bg-purple-700',
  'alkali metal': 'bg-red-700 hover:bg-red-600',
  'alkaline earth metal': 'bg-orange-600 hover:bg-orange-500',
  'metalloid': 'bg-teal-600 hover:bg-teal-500',
  'polyatomic nonmetal': 'bg-green-600 hover:bg-green-500',
  'post-transition metal': 'bg-blue-700 hover:bg-blue-600',
  'transition metal': 'bg-yellow-600 hover:bg-yellow-500',
  'lanthanide': 'bg-indigo-600 hover:bg-indigo-500',
  'actinide': 'bg-pink-700 hover:bg-pink-600',
  'unknown, probably transition metal': 'bg-gray-600 hover:bg-gray-500',
  'unknown, probably post-transition metal': 'bg-gray-600 hover:bg-gray-500',
  'unknown, probably metalloid': 'bg-gray-600 hover:bg-gray-500',
  'unknown, probably noble gas': 'bg-gray-600 hover:bg-gray-500',
};

const ElementCell: React.FC<ElementCellProps> = ({ element, onClick }) => {
  const colorClass = categoryColors[element.category] || 'bg-gray-700 hover:bg-gray-600';
  const gridPosition = {
    gridColumnStart: element.xpos,
    gridRowStart: element.ypos,
  };

  return (
    <div
      style={gridPosition}
      className={`p-1 md:p-2 border border-gray-700 rounded-md cursor-pointer transition-all duration-200 ease-in-out transform hover:scale-110 hover:z-10 relative ${colorClass}`}
      onClick={onClick}
    >
      <div className="flex justify-between text-xs text-gray-300">
        <span>{element.atomicNumber}</span>
      </div>
      <div className="text-center">
        <h2 className="text-lg md:text-xl font-bold">{element.symbol}</h2>
        <p className="text-xs hidden md:block">{element.name}</p>
      </div>
    </div>
  );
};

export default ElementCell;
