
import React, { useState, useEffect } from 'react';
import { ElementData } from '../types';

interface QuizModalProps {
  elements: ElementData[];
  onClose: () => void;
}

interface QuizState {
  atomicNumber: string;
  protons: string;
  electrons: string;
  neutrons: string;
  massNumber: string;
  valenceElectrons: string;
  electronConfiguration: string;
}

type ValidationState = {
  [key in keyof QuizState]?: boolean;
};

const QuizModal: React.FC<QuizModalProps> = ({ elements, onClose }) => {
  const [currentElement, setCurrentElement] = useState<ElementData | null>(null);
  const [answers, setAnswers] = useState<QuizState>({
    atomicNumber: '',
    protons: '',
    electrons: '',
    neutrons: '',
    massNumber: '',
    valenceElectrons: '',
    electronConfiguration: ''
  });
  const [validation, setValidation] = useState<ValidationState>({});
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);

  // Chọn ngẫu nhiên một nguyên tố khi component mount hoặc khi chuyển câu hỏi
  const generateQuestion = () => {
    const randomIndex = Math.floor(Math.random() * elements.length);
    setCurrentElement(elements[randomIndex]);
    setAnswers({
      atomicNumber: '',
      protons: '',
      electrons: '',
      neutrons: '',
      massNumber: '',
      valenceElectrons: '',
      electronConfiguration: ''
    });
    setValidation({});
    setShowResult(false);
  };

  useEffect(() => {
    generateQuestion();
  }, []);

  const calculateValenceElectrons = (config: string): number => {
    // Logic: Tìm số lượng tử chính (n) lớn nhất trong chuỗi cấu hình
    // Ví dụ: [He] 2s2 2p5 -> Max n = 2. Tổng e ở lớp 2 = 2 + 5 = 7.
    // Ví dụ: [Ar] 3d10 4s2 -> Max n = 4. Tổng e ở lớp 4 = 2.
    
    // Loại bỏ phần lõi khí hiếm (VD: [He], [Ar]) để tính toán phần còn lại
    // Tuy nhiên, với các nguyên tố d và f block, e hóa trị có thể phức tạp hơn.
    // Ở mức phổ thông, thường tính e lớp ngoài cùng (lớp vỏ n lớn nhất).
    
    const cleanConfig = config.replace(/\[.*?\]/g, '').trim();
    const parts = cleanConfig.split(' ');
    
    let maxN = 0;
    
    // Tìm lớp n lớn nhất
    parts.forEach(part => {
        if(!part) return;
        const match = part.match(/^(\d+)[spdf](\d+)$/);
        if (match) {
            const n = parseInt(match[1]);
            if (n > maxN) maxN = n;
        }
    });

    // Nếu config rỗng (ví dụ H, He có thể được viết đầy đủ mà không có core), check lại
    // Với H (1s1), He (1s2), maxN = 1.
    if (maxN === 0) {
        // Fallback cho các nguyên tố nhỏ nếu chuỗi config đầy đủ (VD: 1s2)
        const fullParts = config.split(' ');
        fullParts.forEach(part => {
             const match = part.match(/^(\d+)[spdf](\d+)$/);
             if (match) {
                 const n = parseInt(match[1]);
                 if (n > maxN) maxN = n;
             }
        });
    }

    let totalValence = 0;
    const allParts = config.replace(/\[.*?\]/g, ' ').split(' '); // Chỉ tính phần đuôi
    
    // Nếu là nguyên tố nhóm s hoặc p, đếm e ở lớp maxN
    // Nếu config dạng [Noble] ... thì chỉ cần duyệt phần đuôi là đủ cho hầu hết trường hợp
    
    // Để chính xác nhất với hiển thị: duyệt cả chuỗi gốc (nếu nó không viết tắt) hoặc chuỗi đuôi
    // Cách đơn giản: Duyệt chuỗi hiển thị, tìm tất cả các phân lớp thuộc lớp maxN
    
    const configToScan = config.includes('[') ? config.split(']')[1] : config;
    
    const subshells = configToScan.trim().split(' ');
    subshells.forEach(sub => {
        const match = sub.match(/^(\d+)[spdf](\d+)$/);
        if (match) {
            const n = parseInt(match[1]);
            const e = parseInt(match[2]);
            if (n === maxN) {
                totalValence += e;
            }
        }
    });
    
    // Fallback đặc biệt cho Helium (1s2) -> 2e, nhưng nó là khí hiếm. Logic trên trả về 2.
    // Fallback cho [He] 2s1 (Li) -> maxN=2, 2s1 -> 1e.
    
    // Nếu logic trên trả về 0 (do parse lỗi), thử fallback bằng Group number
    if (totalValence === 0 && currentElement) {
        const g = currentElement.group;
        if (g <= 2) return g;
        if (g >= 13 && g <= 18) return g - 10;
        // Transition metals thường có 2e lớp ngoài cùng (ns2), đôi khi 1.
        return 2; 
    }

    return totalValence;
  };

  const handleSubmit = () => {
    if (!currentElement) return;

    const massNum = Math.round(currentElement.atomicMass);
    const neutronNum = massNum - currentElement.atomicNumber;
    const valenceNum = calculateValenceElectrons(currentElement.electronConfiguration);

    const checks: ValidationState = {
      atomicNumber: parseInt(answers.atomicNumber) === currentElement.atomicNumber,
      protons: parseInt(answers.protons) === currentElement.atomicNumber,
      electrons: parseInt(answers.electrons) === currentElement.atomicNumber,
      massNumber: parseInt(answers.massNumber) === massNum,
      neutrons: parseInt(answers.neutrons) === neutronNum,
      valenceElectrons: parseInt(answers.valenceElectrons) === valenceNum,
      // Cấu hình e: So sánh chuỗi (bỏ qua khoảng trắng thừa và chữ hoa/thường)
      electronConfiguration: answers.electronConfiguration.replace(/\s+/g, '').toLowerCase() === currentElement.electronConfiguration.replace(/\s+/g, '').toLowerCase()
    };

    setValidation(checks);
    setShowResult(true);

    // Tính điểm đơn giản: đếm số câu đúng
    const correctCount = Object.values(checks).filter(v => v).length;
    if (correctCount === 7) {
        setScore(s => s + 10);
    }
  };

  const handleInputChange = (field: keyof QuizState, value: string) => {
    setAnswers(prev => ({ ...prev, [field]: value }));
  };

  const getInputClass = (field: keyof QuizState) => {
    const baseClass = "w-full bg-gray-700 border rounded-md px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-cyan-500 font-mono";
    if (!showResult) return `${baseClass} border-gray-600`;
    return validation[field] 
      ? `${baseClass} border-green-500 bg-green-900/20` 
      : `${baseClass} border-red-500 bg-red-900/20`;
  };

  if (!currentElement) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <div className="bg-gray-800 rounded-lg shadow-2xl w-full max-w-2xl p-6 border border-gray-700" onClick={e => e.stopPropagation()}>
        
        <div className="flex justify-between items-center mb-6 border-b border-gray-700 pb-4">
          <div>
            <h2 className="text-2xl font-bold text-cyan-400">Luyện tập kiến thức</h2>
            <p className="text-gray-400 text-sm">Điền thông tin cho nguyên tố bên dưới</p>
          </div>
          <div className="text-right">
            <span className="block text-sm text-gray-500">Điểm số</span>
            <span className="text-xl font-bold text-green-400">{score}</span>
          </div>
        </div>

        <div className="mb-6 text-center p-4 bg-gray-900 rounded-lg border border-gray-700">
          <span className="text-6xl font-bold text-white block mb-2">{currentElement.symbol}</span>
          <span className="text-xl text-cyan-300">{currentElement.name}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            
          <div className="space-y-4">
            <div>
              <label className="block text-xs text-gray-400 mb-1">Số hiệu nguyên tử (Z)</label>
              <input 
                type="number" 
                value={answers.atomicNumber}
                onChange={(e) => handleInputChange('atomicNumber', e.target.value)}
                className={getInputClass('atomicNumber')}
                disabled={showResult}
              />
              {showResult && !validation.atomicNumber && <p className="text-xs text-red-400 mt-1">Đáp án: {currentElement.atomicNumber}</p>}
            </div>

            <div>
              <label className="block text-xs text-gray-400 mb-1">Số Proton (p)</label>
              <input 
                type="number" 
                value={answers.protons}
                onChange={(e) => handleInputChange('protons', e.target.value)}
                className={getInputClass('protons')}
                disabled={showResult}
              />
               {showResult && !validation.protons && <p className="text-xs text-red-400 mt-1">Đáp án: {currentElement.atomicNumber}</p>}
            </div>

            <div>
              <label className="block text-xs text-gray-400 mb-1">Số Electron (e)</label>
              <input 
                type="number" 
                value={answers.electrons}
                onChange={(e) => handleInputChange('electrons', e.target.value)}
                className={getInputClass('electrons')}
                disabled={showResult}
              />
               {showResult && !validation.electrons && <p className="text-xs text-red-400 mt-1">Đáp án: {currentElement.atomicNumber}</p>}
            </div>
          </div>

          <div className="space-y-4">
             <div>
              <label className="block text-xs text-gray-400 mb-1">Số khối (A) (làm tròn)</label>
              <input 
                type="number" 
                value={answers.massNumber}
                onChange={(e) => handleInputChange('massNumber', e.target.value)}
                className={getInputClass('massNumber')}
                disabled={showResult}
              />
               {showResult && !validation.massNumber && <p className="text-xs text-red-400 mt-1">Đáp án: {Math.round(currentElement.atomicMass)}</p>}
            </div>

            <div>
              <label className="block text-xs text-gray-400 mb-1">Số Neutron (N = A - Z)</label>
              <input 
                type="number" 
                value={answers.neutrons}
                onChange={(e) => handleInputChange('neutrons', e.target.value)}
                className={getInputClass('neutrons')}
                disabled={showResult}
              />
               {showResult && !validation.neutrons && <p className="text-xs text-red-400 mt-1">Đáp án: {Math.round(currentElement.atomicMass) - currentElement.atomicNumber}</p>}
            </div>

            <div>
              <label className="block text-xs text-gray-400 mb-1">Số e lớp ngoài cùng</label>
              <input 
                type="number" 
                value={answers.valenceElectrons}
                onChange={(e) => handleInputChange('valenceElectrons', e.target.value)}
                className={getInputClass('valenceElectrons')}
                disabled={showResult}
              />
               {showResult && !validation.valenceElectrons && <p className="text-xs text-red-400 mt-1">Đáp án: {calculateValenceElectrons(currentElement.electronConfiguration)}</p>}
            </div>
          </div>
        </div>
        
        <div className="mb-6">
            <label className="block text-xs text-gray-400 mb-1">Cấu hình Electron (Ví dụ: [He] 2s2)</label>
            <input 
                type="text" 
                value={answers.electronConfiguration}
                onChange={(e) => handleInputChange('electronConfiguration', e.target.value)}
                className={getInputClass('electronConfiguration')}
                disabled={showResult}
                placeholder="Nhập cấu hình..."
            />
            {showResult && !validation.electronConfiguration && <p className="text-xs text-red-400 mt-1">Đáp án: {currentElement.electronConfiguration}</p>}
        </div>

        <div className="flex justify-end gap-3">
          <button 
            onClick={onClose} 
            className="px-4 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-lg font-medium transition"
          >
            Đóng
          </button>
          
          {!showResult ? (
            <button 
                onClick={handleSubmit} 
                className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg font-bold transition shadow-lg shadow-cyan-500/30"
            >
                Kiểm tra đáp án
            </button>
          ) : (
            <button 
                onClick={generateQuestion} 
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-lg font-bold transition shadow-lg shadow-purple-500/30 flex items-center"
            >
                Câu hỏi tiếp theo
                <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7l5 5m0 0l-5 5m5-5H6"></path></svg>
            </button>
          )}
        </div>

      </div>
    </div>
  );
};

export default QuizModal;
