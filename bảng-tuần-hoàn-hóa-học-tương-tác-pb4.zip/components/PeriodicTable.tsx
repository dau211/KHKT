
import React from 'react';
import { ElementData } from '../types';
import ElementCell from './ElementCell';

interface PeriodicTableProps {
  elements: ElementData[];
  onElementClick: (element: ElementData) => void;
}

const PeriodicTable: React.FC<PeriodicTableProps> = ({ elements, onElementClick }) => {
  return (
    <div className="w-full overflow-x-auto">
        <div 
          className="grid gap-1 mx-auto"
          style={{ 
            gridTemplateColumns: 'repeat(18, minmax(0, 1fr))', 
            gridTemplateRows: 'repeat(10, minmax(0, 1fr))',
            width: '100%',
            maxWidth: '1200px'
          }}
        >
          {elements.map((element) => (
            <ElementCell
              key={element.atomicNumber}
              element={element}
              onClick={() => onElementClick(element)}
            />
          ))}
        </div>
    </div>
  );
};

export default PeriodicTable;
